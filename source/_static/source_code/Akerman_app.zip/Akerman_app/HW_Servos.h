#ifndef HW_Servos_h
#define HW_Servos_h

#include <inttypes.h>

#define DEV_ADDR  0x32
#define SERVOS_ADDR 0xB0

class Servos
{
  private:
    int8_t offset[4];  //This value is used by the set_offset function
  public:
    void begin(void);
    
    /* Servo offset control function */
    bool set_offset(uint8_t id, int8_t val);

    /**
     * @brief Servo position control function
     * 
     * @param  id
     *  @arg Motor ID, either 1 or 2 
     * @param  pwm
     *  @arg Servo PWM setting, adjustable range: 500 ~ 2500
     * 
     * @return true or flase
     */
    bool set_servo(uint8_t id, uint16_t pwm);
};

#endif
