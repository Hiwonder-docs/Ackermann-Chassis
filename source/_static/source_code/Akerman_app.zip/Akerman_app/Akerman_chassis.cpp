#include "Akerman_chassis.h"

#define PI 3.141592654f

static inline float linear_speed_to_rps(AkermanObjectTypeDef *self,  float speed)
{
    return speed / (PI * self->wheel_diameter);
}

  //[1100,1900] 1900-36 1100--36
/* Linear velocity is positive in the counterclockwise direction */

void Akerman::begin(uint8_t type)
{
  if(type == TIACKER_CHASSIS){
    akerman.shaft_length = TIACKER_SHAFT_LENGTH;
    akerman.wheel_diameter = TIACKER_WHEEL_DIAMETER;
    akerman.correction_factor = TIACKER_CORRECITION_FACTOR;
    akerman.wheelbase = TIACKER_WHEELBASE;
    akerman.motor_type = MOTOR_TYPE_TT;
    akerman.chassis_type = type;
  }else if(type == MINACKER_CHASSIS){
    akerman.shaft_length = MINACKER_SHAFT_LENGTH;
    akerman.wheel_diameter = MINACKER_WHEEL_DIAMETER;
    akerman.correction_factor = MINACKER_CORRECITION_FACTOR;
    akerman.wheelbase = MINACKER_WHEELBASE;
    akerman.motor_type = MOTOR_TYPE_JGB37_520R30;
    akerman.chassis_type = type;
  }
    akerman.vl = 0;
    akerman.vr = 0;
    akerman.angle = 0;
    motor.begin();
    servos.begin();

}

/* v -> mm/s      r -> mm */
void Akerman::move(float v, float r)
{
  float akerman_vr, akerman_vl, akerman_angle;

  if(r == 0.0f)
  {
      akerman_vl = v;
      akerman_vr = v;
      akerman_angle = 0;
  }
  else
  {
      akerman_vl = v / r * (r + akerman.wheelbase / 2);
      akerman_vr = v / r * (r - akerman.wheelbase / 2);
      akerman_angle = atan(akerman.shaft_length / r);
  }

  if(akerman_angle >= PI / 5.0f)
  {
      akerman_angle = PI / 5.0f;
  }
  else if(akerman_angle <= -PI / 5.0f)
  {
      akerman_angle = -PI / 5.0f;
  }

  if(akerman.chassis_type == TIACKER_CHASSIS){
    akerman.angle = -2000 / PI * akerman_angle + 1500; //Calculate the steering angle
  }else if(akerman.chassis_type == MINACKER_CHASSIS){
    akerman.angle = 2000 / PI * akerman_angle + 1500; //Calculate the steering angle
  }
  
  akerman.vl = linear_speed_to_rps(&akerman,  akerman_vl);
  akerman.vr = linear_speed_to_rps(&akerman,  akerman_vr);

  servos.set_servo(4, (uint16_t)akerman.angle);  
  motor.set_speed(akerman.motor_type, 1, 0, akerman.vr);
  motor.set_speed(akerman.motor_type, 2, 0, akerman.vl); 

}

float Akerman::get_right_wheel_speed_result()
{
    return motor.get_speed(1);
}

float Akerman::get_left_wheel_speed_result()
{
    return motor.get_speed(2);
}

float Akerman::cal_right_wheel_speed()
{
    return akerman.vr;
}

float Akerman::cal_left_wheel_speed()
{
    return akerman.vl;
}

float Akerman::cal_servo_angle_result()
{
    return akerman.angle;
}