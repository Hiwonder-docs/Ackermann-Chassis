#include "HW_Motor.h"
#include "Wire.h"

/*  Get the low 8 bits of A */
#define GET_LOW_BYTE(A) ((uint8_t)(A))
/* Get the high 8 bits of A */
#define GET_HIGH_BYTE(A) ((uint8_t)((A) >> 8))
/* Combine high and low 8 bits into a 16-bit value */
#define BYTE_TO_HW(A, B) ((((uint16_t)(A)) << 8) | (uint8_t)(B))

/* Write single byte */
static bool write_byte(uint8_t addr, uint8_t val)
{
    Wire.beginTransmission(addr);
    Wire.write(val);
    if( Wire.endTransmission() != 0 ) 
    {
        return false;
    }
    return true; 
}

/* Write multiple bytes */
static bool write_data_array(uint8_t addr, uint8_t reg, uint8_t *val, uint16_t len)
{
    uint16_t i;
    Wire.beginTransmission(addr);
    Wire.write(reg);
    for(i = 0; i < len; i++) 
    {
        Wire.write(val[i]);
    }
    if( Wire.endTransmission() != 0 ) 
    {
        return false;
    }
    return true;
}

static float map(float x, float in_min, float in_max, float out_min, float out_max)
{
    return out_min + ((x - in_min) * (out_max - out_min) / (in_max - in_min));
}

static bool read_data_array(uint8_t addr, uint8_t reg, uint8_t *val, uint16_t len)
{
    uint16_t i = 0;
    /* Indicate which register we want to read from */
    if (!write_byte(addr, reg)) 
    {

        return false;
    }
    Wire.requestFrom(addr, len);
    while (Wire.available()) 
    {
        if (i >= len) 
        {
            return false;
        }
        val[i] = Wire.read();
        i++;
    }  
    return true;  
}

void Motor::begin()
{
    Wire.begin();
}

bool Motor::set_speed(uint8_t motor_type, uint8_t id, uint8_t mode, float speed)
{
    float trans_speed;
    uint8_t set_speed_8bit[7];

    if(mode == 0)
    {
        trans_speed = speed;
    }
    else if(mode == 1)
    {
        trans_speed = map(speed, -100, 100, -1600, 1600);
    }
    
    set_speed_8bit[0] = motor_type;
    set_speed_8bit[1] = id;
    set_speed_8bit[2] = mode;
    memcpy(set_speed_8bit + 3, &trans_speed, sizeof(trans_speed));
    write_data_array(DEV_ADDR, SET_SPEED_ADDR, set_speed_8bit, sizeof(set_speed_8bit));
    return true;
}

float Motor::get_speed(uint8_t id)
{
  if(id < 1 || id > 2)
  {
      return false;
  }
  uint8_t get_speed_8bit[4];
  float vel;
  write_data_array(DEV_ADDR, GET_SPEED_ADDR, &id, sizeof(id));
  read_data_array(DEV_ADDR, GET_SPEED_ADDR, get_speed_8bit, sizeof(get_speed_8bit));
  memcpy(&vel, get_speed_8bit, sizeof(vel));
  return vel;
}

uint16_t Motor::get_encoder_count(uint8_t id)
{
    if(id < 1 || id > 2)
    {
        return false;
    }
    uint8_t encoder_value_8bit[4];
    uint16_t vel;
    write_data_array(DEV_ADDR, GET_ENCODER_COUNT_ADDR, &id, sizeof(id));
    read_data_array(DEV_ADDR, GET_ENCODER_COUNT_ADDR, encoder_value_8bit, sizeof(encoder_value_8bit));
    memcpy(&vel, encoder_value_8bit, sizeof(vel));
    return vel;
}

bool Motor::clear_encoder_count(uint8_t id)
{
    if(id < 1 || id > 2)
    {
        return false;
    }
    uint8_t encoder_value_8bit[4];
    float vel;
    write_data_array(DEV_ADDR, CLEAR_ENCODER_COUNT_ADDR, &id, sizeof(id));
    return true;
}