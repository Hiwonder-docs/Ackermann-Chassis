#ifndef HW_Motor_h
#define HW_Motor_h

#include "Arduino.h"
#include "inttypes.h"

#define DEV_ADDR 0x32

/* Motor speed control register */
#define SET_SPEED_ADDR            0xC0

/* Motor speed read register */
#define GET_SPEED_ADDR            0xC1

/* Encoder value read register */
#define GET_ENCODER_COUNT_ADDR    0xC2

/* Encoder value clear register */
#define CLEAR_ENCODER_COUNT_ADDR  0xC3

/* High-speed geared motor, gear ratio: 1:48 */
#define MOTOR_TYPE_TT             0xCA

/* JGB37-520 Hall-effect DC geared encoder motor, gear ratio: 1:30 */
#define MOTOR_TYPE_JGB37_520R30      0xCB



class Motor
{
  public:
    void begin();
    
    /**
     * @brief Motor speed setting function
     * 
     * @param  motor_type 
     *  @arg  MOTOR_TYPE_TT
     *  @arg  MOTOR_TYPE_JGB37_520R30
     *
     * @param  id 
     *  @arg  Motor ID, must be 1 or 2
     * 
     * @param  mode 
     *  @arg  0-Closed-loop control
     *  @arg  1-Open-loop control
     * 
     * @param  velocity 
     *  @arg -In open-loop mode: adjustable range is -100 to 100, where the sign indicates direction
     *       -In closed-loop mode: adjustable range is -4.3 to 4.3, unit: rps (revolutions per second)
     * @return true  -Setting successful
     *         false -Setting failed
     */
    bool set_speed(uint8_t motor_type, uint8_t id, uint8_t mode, float velocity);

    /**
     * @brief Get motor speed
     * 
     * @param  id 
     *  @arg Motor ID, must be 1 or 2
     * 
     * @return Motor speed
     */
    float get_speed(uint8_t id);

    /**
     * @brief Get encoder count from the motor
     * 
     * @param  id 
     *  @arg Motor ID, must be 1 or 2
     * 
     * @return Encoder count value (range: [0, 65535])
     */
    uint16_t get_encoder_count(uint8_t id);

     /**
     * @brief Clear encoder count of the motor
     * 
     * @param  id 
     *  @arg Motor ID, must be 1 or 2
     * 
     * @return true  -Successfully cleared
     *         false -Failed to clear 
     */
    bool clear_encoder_count(uint8_t id);   
};

#endif