#include "HW_Servos.h"
#include "Wire.h"

/*  Get the low 8 bits of A */
#define GET_LOW_BYTE(A) ((uint8_t)(A))
/* Get the high 8 bits of A */
#define GET_HIGH_BYTE(A) ((uint8_t)((A) >> 8))
/* Combine high and low 8 bits into a 16-bit value */
#define BYTE_TO_HW(A, B) ((((uint16_t)(A)) << 8) | (uint8_t)(B))

/* Write single byte */
static bool write_byte(uint8_t addr, uint8_t val)
{
    Wire.beginTransmission(addr);
    Wire.write(val);
    if( Wire.endTransmission() != 0 ) 
    {
        return false;
    }
    return true; 
}

/* Write multiple bytes */
static bool write_data_array(uint8_t addr, uint8_t reg, uint8_t *val, uint16_t len)
{
    uint16_t i;
    Wire.beginTransmission(addr);
    Wire.write(reg);
    for(i = 0; i < len; i++) 
    {
        Wire.write(val[i]);
    }
    if( Wire.endTransmission() != 0 ) 
    {
        return false;
    }
    return true;
}

static bool read_data_array(uint8_t addr, uint8_t reg, uint8_t *val, uint16_t len)
{
    uint16_t i = 0;
    /* Indicate which register we want to read from */
    if (!write_byte(addr, reg)) 
    {
        return false;
    }
    Wire.requestFrom(addr, len);
    while (Wire.available()) 
    {
        if (i >= len) 
        {
            return false;
        }
        val[i] = Wire.read();
        i++;
    }  
    return true;  
}

void Servos::begin()
{
    Wire.begin();
    for(uint8_t i = 0; i < 4; i++)
    {
      offset[i] = 0;
    }
}

bool Servos::set_offset(uint8_t id, int8_t val)
{
    if(id <1 || id > 4)
    {
        return false;
    }
    offset[id - 1] = val;
    return true;
}

bool Servos::set_servo(uint8_t id, uint16_t pwm)
{   
    if(id <1 || id > 4)
    {
        return false;
    }
    if(pwm < 500|| pwm > 2500)
    {
      return false;
    }
    uint8_t send_data[3]; 
    uint16_t total_pwm;
    total_pwm = pwm + offset[id - 1];
    send_data[0] = id;
    send_data[1] = GET_LOW_BYTE(total_pwm);
    send_data[2] = GET_HIGH_BYTE(total_pwm);
    write_data_array(DEV_ADDR, SERVOS_ADDR, send_data, sizeof(send_data));
    return true;
}
