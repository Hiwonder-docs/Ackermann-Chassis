#ifndef AKERMAN_CHASSIS_H
#define AKERMAN_CHASSIS_H

#include "HW_Motor.h"
#include "HW_Servos.h"

#define TIACKER_CHASSIS 1
#define TIACKER_WHEEL_DIAMETER 68.0 /* mm */
#define TIACKER_CORRECITION_FACTOR 1.0 /* mm */
#define TIACKER_SHAFT_LENGTH 121.0 /* mm */
#define TIACKER_WHEELBASE  160.0 /* mm */

#define MINACKER_CHASSIS 2
#define MINACKER_WHEEL_DIAMETER 68.0 /* mm */
#define MINACKER_CORRECITION_FACTOR 1.0 /* mm */
#define MINACKER_SHAFT_LENGTH 170.0 /* mm */
#define MINACKER_WHEELBASE  180.0 /* mm */


#ifdef __cplusplus
extern "C" 
{
#endif

typedef struct
{
  float shaft_length;
  float wheel_diameter;
  float correction_factor;
  float wheelbase;
  float vr;
  float vl;
  float angle;
  uint8_t motor_type;
  uint8_t chassis_type;
}AkermanObjectTypeDef;



#ifdef __cplusplus
} // extern "C"
#endif



class Akerman
{
  private:
    AkermanObjectTypeDef akerman;
    Motor motor;
    Servos servos;

  public:
    void begin(uint8_t type);
    /**
     * @brief Chassis motion function
     * 
     * @param  motor_type
     *  @arg MOTOR_TYPE_TT
     *  @arg MOTOR_TYPE_JGB37_520R30
     * 
     * @param  v
     *  @arg Linear velocity of the car, unit: mm/s
     *
     * @param  r
     *  @arg Turning radius of the car, unit: mm   
     *  
     * @return NULL
     *         
     */
    void move(float v, float r);
    float get_right_wheel_speed_result(void);
    float get_left_wheel_speed_result(void);
    float cal_right_wheel_speed(void);
    float cal_left_wheel_speed(void);
    float cal_servo_angle_result(void);
};

#endif