#!/usr/bin/python3
# coding=utf8
import sys
import rospy
import serial
import pigpio
import time
import RPi.GPIO as GPIO


from chassis_control.msg import *
# from BusServoCmd import *
from smbus2 import SMBus, i2c_msg
from rpi_ws281x import PixelStrip
from rpi_ws281x import Color as PixelColor

if sys.version_info.major == 2:
    print('Please run this program with python3!')
    sys.exit(0)
    
print('''
**********************************************************
********************功能：阿克曼小车例程********************
**********************************************************
----------------------------------------------------------
Official website:https://www.hiwonder.com
Online mall:https://hiwonder.tmall.com
----------------------------------------------------------
Tips:
 * 按下Ctrl+C可关闭此次程序运行，若失败请多次尝试！
----------------------------------------------------------
''')

LOBOT_SERVO_MOVE_TIME_WRITE      = 1

car_speed = 0 # 小车速度
car_speed_move = 80
car_wheel_angle = 90  # 小车方向角，保持默认即可
car_wheel_rotate = 0  # 小车偏航参数，保持默认即可
car_turn_mode = ['go','back','turn_left','left_back','turn_right','right_back']

# 转向舵机控制角度
steering_servor_angle_pulse = 1500  # 中位位置 （500 -- 2500）
steering_serv_turn_time = 100  # 目标角度的时间

start = True
pin = 12 # 前转向轮的舵机io口

pi = pigpio.pi()
pi.set_PWM_range(pin, 20000)#5是要输出PWM的IO口， 20000设定PWM的调节范围，
                          #我们的舵机的控制信号是50Hz，就是20ms为一个周期。就是20000us。
                          #设为20000,就是最小调节为1us
pi.set_PWM_frequency(pin, 50) #设定PWM的频率，5是要设定的IO口， 50 是频率
pi.set_PWM_dutycycle(pin, 1500)

def servo_angle(dc):
    pi.set_PWM_dutycycle(pin, dc) #设定pwm的脉宽， pin为引脚，i为脉宽
    time.sleep(0.5)

#关闭前处理
def stop():
    global start

    start = False
    print('关闭中...')
    set_velocity.publish(0,0,0)  # 发布底盘控制消息,停止移动
    
if __name__ == '__main__':
    # 初始化节点
    rospy.init_node('car_forward_demo', log_level=rospy.DEBUG)
    rospy.on_shutdown(stop)
    # 底盘控制
    set_velocity = rospy.Publisher('/chassis_control/set_velocity', SetVelocity, queue_size=1)
    set_velocity.publish(car_speed,car_wheel_angle,car_wheel_rotate)
    servo_angle(steering_servor_angle_pulse)
    mode = None  # 运动模式
    i = 0
    while start:
        # 发布底盘控制消息,线速度60，偏航角速度0(小于0，为顺时针方向)
        # 小车向前运动
        rospy.sleep(1)
        if i >= 6:
            i = 0
        mode = car_turn_mode[i]
        # car_speed 表示小车速度
        # steering_servor_angle = 表示舵机转到的的角度
        if mode == 'go':
            car_speed = car_speed_move
            steering_servor_angle_pulse = 1500
        elif mode == 'back':
            car_speed = -car_speed_move
            steering_servor_angle_pulse = 1500
        elif mode == 'turn_left':
            car_speed = car_speed_move
            steering_servor_angle_pulse = 1000
        elif mode == 'left_back':
            car_speed = -car_speed_move
            steering_servor_angle_pulse = 1000
        elif mode == 'turn_right':
            car_speed = car_speed_move
            steering_servor_angle_pulse = 2000
        elif mode == 'right_back':
            car_speed = -car_speed_move
            steering_servor_angle_pulse = 2000
        else:
            print('wait the message')
        print("当前运行的模式：",mode)
        set_velocity.publish(car_speed,car_wheel_angle,car_wheel_rotate)  # 小车速度
        servo_angle(steering_servor_angle_pulse)
        rospy.sleep(3)
        set_velocity.publish(0,90,0)  
        rospy.sleep(1)
        i += 1

        
    set_velocity.publish(0,0,0)  # 发布底盘控制消息,停止移动
    print('已关闭')
        
